package com.example.repository;

public class BookRepository {
	public void getBook() {
        System.out.println("book fetched successfully.");
    }
}



